module.exports = path => {
  return require(path);
};
