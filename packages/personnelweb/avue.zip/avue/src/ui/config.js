export default {
  is: '$isEle',
  name: 'element-ui',
  type: 'el'
}